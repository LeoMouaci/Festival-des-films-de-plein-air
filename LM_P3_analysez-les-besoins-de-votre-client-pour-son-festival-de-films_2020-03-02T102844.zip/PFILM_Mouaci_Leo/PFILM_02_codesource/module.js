
$(document).ready(function() {
  

	  
    var numItems = $('li.fancyTab').length;
		
	
			  if (numItems == 12){
					$("li.fancyTab").width('8.3%');
				}
			  if (numItems == 11){
					$("li.fancyTab").width('9%');
				}
			  if (numItems == 10){
					$("li.fancyTab").width('10%');
				}
			  if (numItems == 9){
					$("li.fancyTab").width('11.1%');
				}
			  if (numItems == 8){
					$("li.fancyTab").width('12.5%');
				}
			  if (numItems == 7){
					$("li.fancyTab").width('14.2%');
				}
			  if (numItems == 6){
					$("li.fancyTab").width('16.666666666666667%');
				}
			  if (numItems == 5){
					$("li.fancyTab").width('20%');
				}
			  if (numItems == 4){
					$("li.fancyTab").width('25%');
				}
			  if (numItems == 3){
					$("li.fancyTab").width('33.3%');
				}
			  if (numItems == 2){
					$("li.fancyTab").width('50%');
				}
		  
	 /**
	  * ici j'ai du utiliser js pour ajouter la class 'active' au li selectionné et l'enlever des autres
	  * explication :
	  * la première ligne ($(".fancyTab").each...) selectionne dans le dom tout les composants ayant la class 'fancyTab' et les parcoure (each) afin que le code qui est
	  * entre les crochets du each soit utilisé sur tous.
	  * la seconde ligne ($(this, 'a').click..) crée un evenement lorsqu'on va cliquer sur l'enfant 'a' du .fancyTab en question (this)
	  * la 3eme et 4eme ligne refait un passage sur tout les elements .fancyTab afin d'enlever la class 'active' a celui qui l'a ($(this).removeClass("active"))
	  * la 5eme ligne ajoute la class 'active' a l'element parent du a sur lequel on vient de cliquer ($(this).addClass("active"))
	  */
	$(".fancyTab").each(function( index ) {
		$(this, 'a').click(function(e) {
			$(".fancyTab").each(function( index ) {
				$(this).removeClass("active")
			  });
			$(this).addClass("active")
		})
	  });
	
		});